import random
import sys

suit, card, deck = ["Spades","Clubs","Hearts","Diamonds"], ["Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"], []

def highScore():
    file = open("highscore.txt","r")
    hScore = file.read()
    if int(score) > int(hScore):
        file = open("highscore.txt","w")
        file.write(str(score))
        hScore = score
    file.close()
    print("HIGHSCORE:",hScore)

def importDeck():
    global deck
    decktxt = open('deck.txt')
    deckNum = [line.rstrip('\n') for line in decktxt]
    num = 0
    while num != len(deckNum):
        x = int(deckNum[num])
        x2 = int(deckNum[num+1])
        deck += [[card[x2-1],suit[x-1],x2-1]]
        num += 2

def normalDeck():
    global deck
    for i in range(len(card)):
        for s in range(len(suit)):
            deck += [[card[i],suit[s],i]]
    random.shuffle(deck)
    
while True:
    deckSelect = input("Do you want to play the example game? (Y or N) ").upper()
    if deckSelect == "Y" or deckSelect == "N":
        break
    else:
        print("\nYou did not input Y or N")

if deckSelect == "Y":
    importDeck()
else:
    normalDeck()

num, score = 0, 0
while num != 52:
    print("\nThe card is the",deck[num][0],"of",deck[num][1])
    while True:
        choice = input("Will the next card be higher? (Y or N) ").upper()
        if choice == "Y" or choice == "N":
            break
        else:
            print("\nYou did not input Y or N")
    print("")
    if deck[num][2] < deck[num+1][2]:
        HorL = "Y"
    else:
        HorL = "N"
    if choice == HorL:
        score += 1
        print("CORRECT!")
        print("Your score so far is",score)
    else:
        print("Incorrect.")
        print("The next card was the",deck[num+1][0],"of",deck[num+1][1])
        print("\nSCORE:",score)
        highScore()
        sys.exit()
    num += 1

print("YOU WIN!!!")
print("Your score is 52")
