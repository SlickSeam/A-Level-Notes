'''
“Game of life” :  an n-by-n grid of square cells, each of which can be
either "alive" or "dead". A given cell's neighbors are those cells directly
above, below, left, or right of the cell, plus with the cells diagonally
adjacent to it (the cells touching its diagonals).
Each cell changes from one time step to the next according to the following rules:
 ▪Any living cell with fewer than two living neighbors dies.
 ▪Any living cell with exactly two or exactly three living neighbors remains alive.
 ▪Any living cell with more than three living neighbors dies.
 ▪Any dead cell with exactly three living neighbors becomes alive.
 
'''
# import the numpy module to use its matrix (2D array) functions
import numpy as np 
import random

live = 0

# produce a 20x20 grid with values ranging from 0 to 1.
# you can use your own size. But starting with small for easy checking for correctness
myGrid = np.random.randint(0,2,(20,20))
grid2 = np.random.randint(0,2,(20,20))

print(myGrid)
print("")
print(grid2)

# just for your convinence to see what your grid looks like. Can be re-used later
def show():
    global myGrid
    print('\n'*100)
    for l in myGrid:
        print (l)

def find():
    global live, myGrid, grid2
    num = 0
    while num != 20:
        num2 = 0
        while num2 != 20:
            indNum = myGrid[num][num2]
            neighbour(num,num2)
            #############################
            newGrid(indNum,num,num2)
            #############################
            num2 += 1
        num += 1
    gridSwap()
    

def newGrid(indNum,num,num2):
    global grid2, live
    if indNum == 1:
        if live < 2:
            grid2[num][num2] = 0
        if live >= 2:
            if live <=3:
                grid2[num][num2] = 1
        if live > 3:
            grid2[num][num2] = 0

    else:
        if live == 3:
            grid2[num][num2] = 1

def gridSwap():
    global myGrid, grid2
    num = 0
    while num != 20:
        myGrid[num] = grid2[num]
        num += 1
        
    
def neighbour(num,num2):
    global live
    live = 0
    if num > 0:
        if myGrid[num - 1][num2] == 1:
            live += 1
        ######
        if num2 > 0:
            if myGrid[num - 1][num2 - 1] == 1:
                live += 1
        if num2 < 19:
            if myGrid[num - 1][num2 + 1] == 1:
                live += 1
    if num < 19:
        if myGrid[num + 1][num2] == 1:
            live += 1
        ######
        if num2 > 0:
            if myGrid[num + 1][num2 - 1] == 1:
                live += 1
        if num2 < 19:
            if myGrid[num + 1][num2 + 1] == 1:
                live += 1
    if num2 > 0:
        if myGrid[num][num2 - 1] == 1:
            live += 1
    if num2 < 19:
        if myGrid[num][num2 + 1] == 1:
            live += 1
    return live

def mainLoop():
    global myGrid
    run = True
    while run == True:
        show()
        print("")
        input("Press enter ")
        find()
            
mainLoop()

# define a function that computes each cell's neighbour counts for a given grid
# you may refer back to how to use enumerate 

# define a function that workout the cell value at one time step in myGrid

# display multiple steps of cell evolutions to visually check for correctness




















