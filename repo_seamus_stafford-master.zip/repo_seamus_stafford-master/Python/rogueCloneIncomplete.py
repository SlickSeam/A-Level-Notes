import random
import os
os.environ['LINES'] = '40'
os.environ['COLUMNS']= '80'

##HERE IS THE BOARD - YOU CAN EDIT IT TO CHANGE THE LAYOUT OF THE ROOMS, POSITIONS OF MONSTERS AND POSITIONS OF HEALING SHRINES
layout='''___________________________________________________________________________
|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|XXXX      XXXXXXXXXXXXX      A        XXXXXXXXXXXXX       ?    X      XXX|
|XXXX   O  XXXXXXXXXXXXX               XXXXXXXXXXXXX  XXXXXXXX  X  B   XXX|
|XXXX                                  XXXXXXXXXX      XXXXXXX         XXX|
|XXXX      XXXXXXXXXXXXX                               XXXXXXXXXXXXXXXXXXX|
|XXXXXXXXXXXXXXXXXXXXXXX               XXXXXXXXXX   C  XXXXXXXXXXXXXXXXXXX|
|XXXXXXXXXXXXXXXXXXXXXXXXXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXXX        XXXXX|
|XXXXXX                 XXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXXX   ?    XXXXX|
|XXXXXX  XXXXX  XXXX    XXXXXX  XXXXXXXXXXXXXXXXX      XXXXXX        XXXXX|
|XXXXXX  XXXXX  XXXXXXXXXXXXXX  XXXXXXXXXXXXXXXXX  D   XXXXXXXXXXXX  XXXXX|
|XXXXXX  XXXXX                                         XXXX          XXXXX|
|XXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX      XXXX     XXXXXXXXXX|
|XXXXXX  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXXXXXX|
|XXXXXX       E       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX     XXXXXXXXXX|
|XXXXXXXXXXXXXX   F                                             XXXXXXXXXX|
|XXXXXXXXXXXXXX       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|-------------------------------------------------------------------------|
'''

layout2='''___________________________________________________________________________
|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|XXXXXXXXXXX          D XXXXXXXXXX E      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|XXXXXXXX            XXXXXXXXXXXXX       XXXXXXXXXXXXXXXXXXXXXXXXX ?     X|
|XXXXX           XXXXXXXXXXXXX             XXXXXXX        XXXXXXXX   C   X|
|XXXXX  O        XXXXXXXXXXXXX              XXXXX    ?         A X       X|
|XXXXX                                XXXXXXXXXXX                XX      X|
|XXXXXX          XXXXXXXXXXXX     XXXXXXXXXXXXXXX        XXXXXXXXXXXX    X|
|XXXXXXXXXXXXXXXXXXXXXXXXXXXX                            XXXXXXXXXXXX    X|
|X  B    XXXXXXXXXXXXXXXXXXXX     XXXXXXXXXXXXXXXX       XXXXXXXXXXXX    X|
|X      XXXXXXXXXXXXXXXXXXXXX     XXXXXXXXXXXXXXXXXXX     F  XXXXXXXXXX  X|
|XX   XXXXXXXXXXXXXXXXXXXXXXX    XXXXXXXXXXXXXXXXXXXXX       XXXXXXXXX   X|
|XX            ?XXXXXXXXXXXXX    XXXXXXXXXXXXXXXXXXXXX    XXXXXXXXXXXX   X|
|XX      XXXXXXXXXXXXXXXXXXXX    XXXXXXXXXXXXXXXXXXXXX                   X|
|X                                                                       X|
|XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
|-------------------------------------------------------------------------|
'''

## THESE GLOBAL VARIABLE DECIDE THE MONSTER AND PLAYER HIT POINTS
playerHP = 20
A = 20
B = 20
C = 20
D = 20
E = 20
F = 20
monsters = ['A','B','C','D','E','F','G']
monstersDict = {"A": 20, "B": 20, "C": 20, "D": 20, "E": 20, "F": 20, "O": 20}

def genBoard(theLayout):
    '''This function generates the board - do not change it'''
    board = []
    row = []
    for i in theLayout:
        row.append(i)
        if i == '\n':
            board.append(row)
            row = []
    return board

def printBoard(board):
    '''This function prints the board - do not change it'''
    for row in board:
        for character in row:
            print(character, end=" ")

def playerTurn(board):
    '''This function decides on players actions - you could potentially add more actions in here'''
    action = input('What do you want to do ')
    if action in ['w','a','s','d','f']:
        board = move(board,'O',action)
    return board

# finish this function so that the hero can be moved by using keys
def move(board,object_,direction):
    pos = getObjectPosition(board,"O")
    newPos = getObjectPosition(board,"O")
    if direction == "w":
        newPos[0] -= 1
        setObjectPosition(board,"O",newPos,pos)
    elif direction == "s":
        newPos[0] += 1
        setObjectPosition(board,"O",newPos,pos)
    elif direction == "a":
        newPos[1] -= 1
        setObjectPosition(board,"O",newPos,pos)
    elif direction == "d":
        newPos[1] += 1
        setObjectPosition(board,"O",newPos,pos)
    elif direction == "f":
        monster = input("Which monster do you want to attack ")
        fightMonster(board,monster,newPosition)
    return board

#finish this function so the monsters move on the board
def moveMonsters(board):
    '''This function moves monsters around the board'''
    num = [0,1]
    num2 = [-1,1]
    count = 0
    while count != 6 :
        if monstersDict[monsters[count]] > 0:
            monstMove1 = random.choice(num)
            monstMove2 = random.choice(num2)
            monstPos1 = getObjectPosition(board,monsters[count])
            monstPos2 = getObjectPosition(board,monsters[count])
            monstPos2[monstMove1] += monstMove2
            setObjectPosition(board,monsters[count],monstPos2,monstPos1)
        count += 1
    return board
    
def getObjectPosition(board,object_):
    '''Finds specific objects on the board'''
    position = []
    for y,row in enumerate(board):
        for x, thing in enumerate(row):
            if thing == object_:
                position = [y,x]
    return position

def setObjectPosition(board,object_,newPosition,oldPosition):
    '''sets a new position for an object'''
    global playerHP
    if board[newPosition[0]][newPosition[1]] == ' ':
        board[oldPosition[0]][oldPosition[1]] = ' '
        board[newPosition[0]][newPosition[1]] = object_
    if object_ == 'O':
        if board[newPosition[0]][newPosition[1]] == '?':
            monstersDict["O"] = 20
            board[oldPosition[0]][oldPosition[1]] = ' '
            board[newPosition[0]][newPosition[1]] = object_
    if object_ == 'O':
        num = 0
        HP = [2,4,6,8,10]
        while num != 6:
            monster = monsters[num]
            if board[newPosition[0]][newPosition[1]] == monster:
                damage = random.choice(HP)
                monstersDict[monster] -= damage
                monstersDict["O"] -= 2
                print(monstersDict)
                if monstersDict[monster] <= 0:
                    board[oldPosition[0]][oldPosition[1]] = ' '
                    board[newPosition[0]][newPosition[1]] = object_
                if monstersDict["O"] <= 0:
                    print('\n'*100)
                    print("GAME OVER")
                    exit()
            num += 1
    return board

def checkSquare(board,newPosition):
    'checks what is in a square'''
    square = board[newPosition[0]][newPosition[1]]
    return(square)

# finish this function so the hero "O" can fight the monsters
#def fightMonster(board,monster,newPosition):
#    if monster == 
    
def monsterHealth():
    num = 0
    while num != 6:
        monster = monsters[num]
        if monstersDict[monster] < 0:
            monstersDict[monster] = 0   
        print(monsters[num],"HEALTH:",monstersDict[monster])
        num += 1

def resetHealth():
    num = 0
    while num != 7:
        monster = monsters[num]
        monstersDict[monster] = 20
        num += 1        

def mainLoop(currentBoard):
    '''Runs the game'''
    run = True
    while run == True:
        board = currentBoard
        printBoard(board)
        board = playerTurn(board)
        board = moveMonsters(board)
        print('\n'*100)
        num = 0
        win = 0
        while num != 6:
            monster = monsters[num]
            if monstersDict[monster] <= 0:
                win += 1
            num += 1
            if win == 6:
                print("YOU WIN")
                resetHealth()
                run = False
        print("YOUR HEALTH:",monstersDict["O"])
        monsterHealth()              
            
board1 = genBoard(layout)
board2 = genBoard(layout2)
mainLoop(board1)
currentLayout = layout2
mainLoop(board2)

















