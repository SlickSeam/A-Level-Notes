from datetime import date
import pickle

class schoolMember:
    firstName = ""
    lastName = ""
    DoB = ""

    def __init__(self,firstName,lastName,DoB):
        self.firstName = firstName
        self.lastName = lastName
        self.DoB = DoB

    def getFullName(self):
        return (self.firstName + " " + self.lastName)

    def getDoB(self):
        return self.DoB

    def getAge(self):
        now = date.today()
        tYear = now.year
        tMonth = now.month
        
        DoBYear = int(DoB.split("-")[0])
        DoBMonth = int(DoB.split("-")[1])

        if tMonth - DoBMonth < 0:
            age = tYear - DoBYear - 1
        else:
            age = tYear - DoBYear
            
        return age

    def displayInfo(self):
        print('Name: "{}". Date of Birth: "{}"'.format(self.firstName + " " + self.lastName,self.DoB))

class Teacher(schoolMember):
    def __init__(self,firstName,lastName,DoB,salary,dept):
        schoolMember.__init__(self,firstName,lastName,DoB)
        self.salary = salary
        self.dept = dept

    def getSalary(self):
        return self.salary

    def getDept(dept):
        return self.dept

    def displayInfo(self):
        schoolMember.displayInfo(self)
        print('Salary: "{:d}". Department: "{}"'.format(self.salary,self.dept))

class Student(schoolMember):
    def __init__(self,firstName,lastName,DoB,form,tutor):
        schoolMember.__init__(self,firstName,lastName,DoB)
        self.form = form
        self.tutor = tutor

    def getForm(self):
        return self.form

    def getTutor(self):
        return self.tutor

    def displayInfo(self):
        schoolMember.displayInfo(self)
        print('Form: "{}". Tutor: "{}"'.format(self.form,self.tutor))

def saveMembers(members, filename):
    theFile = open(filename, "wb")
    pickle.dump(members,theFile)
    theFile.close()

def loadMembers(filename):
    theFile = open(filename,"rb")
    members = pickle.load(theFile)
    theFile.close()
    return members

filename = input("Give the file name to save: ")
members = []

###OBJECTS###
mem1 = Student("Seam","Stafford","1998-11-26","12F","Gilb")
mem2 = Teacher("John","Johnson","1915-12-19",20000,"English")
mem3 = Student("Dom","PP","1999-01-09","12D","Perez")
mem4 = Teacher("Teachie","McTeacherson","1950-05-21",120000,"Phorensics")
#############

members.append(mem1)
members.append(mem2)
members.append(mem3)
members.append(mem4)

saveMembers(members,filename)
loadedMembers = loadMembers(filename)

#mem1.displayInfo()
#mem2.displayInfo()
#mem3.displayInfo()











