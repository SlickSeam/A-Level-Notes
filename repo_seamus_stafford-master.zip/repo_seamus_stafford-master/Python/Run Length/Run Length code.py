newFile = []
compressDict = {}
compressedFile = []

def importFile():
    global newFile
    file = open("rle-before.txt")
    newFile = [line.rstrip('\n') for line in file]
    return newFile

def compression():
    global newFile
    for ayy in newFile:
        compress = ""
        num = len(ayy)
        start = 0
        start2 = start + 1
        num3 = 1
        while start != num:
            if start == 0:
                if int(ayy[start]) == 0:
                    compress += "a"
                elif int(ayy[start]) == 1:
                    compress += "b"
            num2 = 1
            add = 1
            end = False
            while end == False:
                if start2 > num-1:
                    compress += str(num2)
                    end = True                        
                elif ayy[start] == ayy[start2]:
                    num2 += 1
                else:
                    compress += str(num2)
                    end = True
                if start == num:
                    end = True
                start += 1
                start2 += 1
            num3 += 1
        compressedFile.append(compress)

def fileWrite():
    file = open("rle-after.txt", "w")
    for line in compressedFile:
        file.write(str(line))
        file.write("\n")
    file.close()

importFile()
compression()
fileWrite()

