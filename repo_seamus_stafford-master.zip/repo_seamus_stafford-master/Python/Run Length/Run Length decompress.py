def decompression():
    decompressFile = open("rle-after.txt")
    decompressed = []
    decompressedLines = [line.rstrip('\n') for line in decompressFile]
    for lmao in decompressedLines:
        num = 0
        decompress = ""
        if lmao[num] == "a":
            num += 1
            num3 = 0
            while num3 != int(lmao[num]):
                decompress += "0"
                num3 += 1
            zo = 0
        elif lmao[num] == "b":
            num += 1
            num3 = 0
            while num3 != int(lmao[num]):
                decompress += "1"
                num3 += 1
            zo = 1
        num += 1
        while num != len(lmao):
            if zo == 0:
                num2 = 0
                while num2 != int(lmao[num]):
                    decompress += "1"
                    num2 += 1
                zo = 1
            else:
                num2 = 0
                while num2 != int(lmao[num]):
                    decompress += "0"
                    num2 += 1
                zo = 0
            num += 1
        print(decompress)
        decompressed.append(decompress)

decompression()
