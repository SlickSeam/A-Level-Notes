board = [["X","X","X","X"],["X"," ","b","X"],["X","t"," ","X"],["X","X","X","X"]]
for y, row in enumerate(board):
    print(end = "\n")
    for x, v in enumerate(row):
        print(y,",",x,",",v, end = " ") #prints coordinates

print("")

for y, row in enumerate(board):
    print(end = "\n")
    for x, v in enumerate(row):
        print(v, end = " ") #prints board


