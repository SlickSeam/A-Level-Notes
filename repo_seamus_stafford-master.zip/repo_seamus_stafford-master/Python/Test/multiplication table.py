number = int(input("Input a number "))
count = 1
while count != 10:
    outputNum = number * count
    print(count,"x",number,"=",outputNum)
    count += 1
    
