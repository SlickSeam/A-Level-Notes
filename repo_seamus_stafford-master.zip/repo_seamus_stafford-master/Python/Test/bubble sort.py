testArray = [45, 6, 89, 12, 2, 34, 17, 23]
LastPass = len(testArray)
SwapMade = True

while LastPass == 0 or SwapMade == True:
    SwapMade = False
    for i in range(len(testArray)-1):
        if testArray [i] > testArray [i + 1]:
            Temp = testArray [i]
            testArray [i] = testArray [i + 1]
            testArray [i + 1] = Temp
            SwapMade = True
    LastPass -= 1

print(testArray)

