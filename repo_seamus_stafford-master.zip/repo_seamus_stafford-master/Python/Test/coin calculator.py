money = int(input("How much money do you have? (in pence) "))
print("")
coins = [50,20,10,2,1]
coinDict = {50 : 0, 20:0, 10:0, 2:0, 1:0}

def loop():
    global money
    num = 0
    while money != 0:
        dividing(num)
        num += 1

def dividing(num):
    global money
    divide = True
    while divide == True:
        if money/coins[num] >= 1:
            money -= coins[num]
            coinDict[coins[num]] += 1
        else:
            divide = False

def output():
    num = 0
    print("===YOU WILL NEED===")
    while num != 5:
        pence = str(coins[num])
        pence += "p"
        print(pence,"coins:",coinDict[coins[num]])
        num += 1        

loop()
output()



    
