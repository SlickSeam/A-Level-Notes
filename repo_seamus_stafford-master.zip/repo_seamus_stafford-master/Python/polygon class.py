import math
import matplotlib.pyplot as pl

class polygon:
    def __init__(self,vertices):
        if len(vertices)<3:
            raise Exception("Invalid number of vertices")
        else:
            self.vertices = vertices

    def addPoint(self,vertex):
        self.vertex = vertex
        self.vertices.append(vertex)
        return self.vertices

    def getPerimeter(self):
        

    def plotPoly(self):


    def getNumOfSides(self):
        self.sides = len(self.vertices)
        return self.sides
