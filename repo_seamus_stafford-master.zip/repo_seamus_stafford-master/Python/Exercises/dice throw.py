import random

totalThrows = 0
answer = "y"

while answer == "y" or answer == "Y":
    numberofThrows = 0
    throw = 0
    while throw <> 6:
        throw = random
