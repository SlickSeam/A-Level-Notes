highestNumber <-- USERINPUT
multiplier <-- USERINPUT
num <-- 1

WHILE num != highestNumber
    OUTPUT num * multiplier
    num <-- num + 1
ENDWHILE
