gameBoard = '''*++++++
+++++++
+++++++
+++++++
+++++++
'''

import random
board = []
myX,myY = 0,0
pos1 = 0
pos2 = 0
gameState = 0
run = True

def genBoard():
    global gameBoard,board
    row = []
    for c in gameBoard:
        row.append(c)
        if c == '\n':
            board.append(row)
            row=[]

def randomPos():
    global board,pos1,pos2
    pos1list = [0,1,2,3,4]
    pos2list = [0,1,2,3,4,5,6]

    num1 = 0
    for row in board:
        num2 = 0
        for c in row:
            if c == "*":
                pos2list.remove(num2)
                pos1list.remove(num1)
                
            if c == "t":
                pos2list.remove(num2)
                pos1list.remove(num1)

            if c == "m":
                pos2list.remove(num2)
                pos1list.remove(num1)
            num2 += 1
        num1 += 1
    
    pos1 = random.choice(pos1list)
    pos2 = random.choice(pos2list)
    return pos1, pos2


def printBoard():
    global gameState
    for row in board:
        print("---------------")
        for c in row:
            if gameState == 1:
                if c == "*":
                    c = "M"
                if c == "m":
                    c = "M"
            if gameState == 2:
                if c == "*":
                    c = "*"
                if c == "m":
                    c = "M"
                if c == "t":
                    c = "T"
                if c == "f":
                    c = "F"
            if c == "f":
                c = " "
            if c == "+":
                c = " "
            if c == "t":
                c = " "
            if c == "m":
                if gameState == 3:
                    c = "M"
                else:
                    c = " "
            if c == "f":
                c = " "
            print("|" + c, end ='')
    print("---------------")

def makeMove():
    global board
    direction = input("What direction do you want to move in? ").upper()
    if direction in ["N","E","S","W"]:
        board = move(board,direction)
    return board

def move(board,direction):
    global myX, myY
    
    myOldX, myOldY = myX, myY
    
    move = False
   
    if direction == 'N':
        if myY != 0:
            myY -= 1
            move = True
            
    if direction == 'E':
        if myX != 6:
            myX += 1
            move = True
            
    if direction == 'S':
        if myY != 4:
            myY += 1
            move = True
            
    if direction == 'W':
        if myX != 0:
            myX -=1
            move = True

    checkPos(myY,myX)
    
    if move == True:
        board[myY][myX] = "*"
        board[myOldY][myOldX] = "+"

    return board

def checkPos(myY,myX):
    global gameState 
    if board[myY][myX] == "m":
        gameState = 1
    if board[myY][myX] == "f":
        gameState = 2
    if board[myY][myX] == "t":
        gameState = 3

def monstChase():
    global gameState
    monstPos = getPos(board,"m")
    playPos = getPos(board,"*")
    num = 1

    monstY = monstPos[0]
    monstX = monstPos[1]

    playY = playPos[0]
    playX = playPos[1]

    num = random.randrange(0,2)

    if num == 0:
        if monstPos[0] > playPos[0]:
            monstPos[0] -= 1
        elif monstPos[0] < playPos[0]:
            monstPos[0] += 1
        else:
            num = 1

    if num == 1:
        if monstPos[1] > playPos[1]:
            monstPos[1] -= 1
        elif monstPos[1] < playPos[1]:
            monstPos[1] += 1
        else:
            num = 1

    board[monstPos[0]][monstPos[1]] = "m"
    board[monstY][monstX] = "+"

##    gameState = -1
##    
##    if monstPos[0] > playerPos[0]:
##        if monstPos[0] - 1 == playerPos[0]:
##            gameState += 1
##        monstPos[0] -= num
##    elif monstPos[0] < playerPos[0]:
##        if monstPos[0] + 1 == playerPos[0]:
##            gameState += 1
##        monstPos[0] += num
##    elif monstPos[0] == playerPos[0]:
##            num += 1
##
##    if monstPos[1] > playerPos[1]:
##        if monstPos[1] - 1 == playerPos[1]:
##            gameState += 1
##        monstPos[1] -= num
##    elif monstPos[1] < playerPos[1]:
##        if monstPos[1] + 1 == playerPos[1]:
##            gameState += 1
##        monstPos[1] += num
##    elif monstPos[1] == playerPos[1]:
##            num += 1
##
##    if num == 3:
##        gameState == 1
##
##    if gameState != 1:
##        gameState = 3
##    
##    board[monstPos[0]][monstPos[1]] = "m"
##    board[monstY][monstX] = "+"

    
    
def getPos(board,obj):
    position = []
    for y,row in enumerate(board):
        for x, thing in enumerate(row):
            if thing == obj:
                position = [y,x]
    return position

def randomiseStart():
    global pos1,pos2
    randomPos()
    trap1Y = pos1
    trap1X = pos2
    board[trap1Y][trap1X] = "t"
    randomPos()
    trap2Y = pos1
    trap2X = pos2
    board[trap2Y][trap2X] = "t"
    randomPos()
    monsY = pos1
    monsX = pos2
    board[monsY][monsX] = "m"
    randomPos()
    flaskY = pos1
    flaskX = pos2
    board[flaskY][flaskX] = "f"

def loop():
    global gameState, run
    genBoard()
    randomiseStart()
    num = 0
    while run == True:
        printBoard()
        makeMove()
        monstPos = getPos(board,"m")
        playerPos = getPos(board,"*")
        print("\n" * 50)
        
        if monstPos == playerPos:
            gameState = 1
            board[playerPos[0]][playerPos[1]] = "m"

        if gameState == 2:
            printBoard()
            print("YOU'VE WON!")
            run = False
            
        if gameState == 3:
            if num > 0:
                monstChase()
                monstChase()
            num += 1
            
        playerPos = getPos(board,"*")
        monstPos = getPos(board,"m")

        if len(playerPos) == 0:
            gameState = 1

        if len(monstPos) == 0:
            gameState = 1
            
        if gameState == 1:
            printBoard()
            print("YOU'RE DEAD")
            run = False

def menu():
    print('''======MENU======
1. Start New Game
2. Load Game
3. Save Game
4. Play Training Game
5. Quit
''')
    numList = ["1","2","3","4","5"]
    while True:
        try:
            num = int(input("Option: "))
            if num not in range(1,6):
                print("This isn't an option")
            else:
                break
        except:
            print("You need to enter a number")
        
menu()
loop()


