file = open("diary.txt","r")
text = file.readlines()

newline = ""
for x in text:
    newline += x
newline = newline.replace("\n","  ")

for i in range(0, 208, 9):
    print(newline[i])
