text = input("Input anything ")
plaintext = ""
size = int(input("Input a size for the rail fence "))
textlen = len(text)
num = 0
num2 = 0
ciphertext = ""

for i in text:
    if i == " ":
        plaintext += "_"
    else:
        plaintext += i

while num2 != size:
    num2 += 1
    while num <= textlen:
        ciphertext += plaintext[num]
        num += size
        if num > textlen-1:
            break
    num = 0
    num += num2

print(ciphertext)
