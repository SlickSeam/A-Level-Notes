done = False
numList = []

while done == False:
    while True:
        try:
            inp = input("Enter any number ")
            numList.append(int(inp))
            break
        except:
            if inp.upper() == "DONE":
                if len(numList) > 0:
                    done = True
                    break
            print("You need to enter a number")

total = 0
highestNum = numList[0]
lowestNum = numList[0]
for number in numList:
    if number > highestNum:
        highestNum = number
    elif number < lowestNum:
        lowestNum = number
    total += number
mean = total/len(numList)
rangeNum = highestNum - lowestNum

belowMean = 0
aboveMean = 0
for number in numList:
    if number > mean:
        aboveMean += 1
    elif number < mean:
        belowMean += 1   

print("")
print("================STATS================")
print("HIGHEST NUMBER:",highestNum)
print("LOWEST NUMBER:",lowestNum)
print("MEAN:",mean)
print("RANGE:",rangeNum)
print("TOTAL NUMBERS ABOVE MEAN:",aboveMean)
print("TOTAL NUMBERS BELOW MEAN:",belowMean)
        
        
