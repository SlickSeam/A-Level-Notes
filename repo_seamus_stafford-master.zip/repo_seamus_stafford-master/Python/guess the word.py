while True:
    try:
        word, guesses, hidden = input("Enter a word or phrase ").upper(), [" "], ""
        length = len(word)
        if length < 9:
            print("\nThis is not bigger than 10 characters\n")
        else:
            break
    except:
        print("You need to enter a new word or phrase")    
print('\n'*100)

def check():
    global hidden
    hidden = ""
    for i in word:
        num = 0
        num2 = 0
        while num != len(guesses):
            if i == guesses[num]:
                hidden += guesses[num]
                num2 = 1
            num += 1
        if num2 != 1:
            hidden += "*"
            
check()
print("WORD:", hidden)
while word != hidden:
    guess = input("\nGuess a letter ").upper()
    if guess not in guesses:
        guesses.append(guess)
    check()
    print("\nWORD:", hidden,"\n")
    if word == hidden:
        print("You guessed the word!")
        break
    wordGuess = input("Now have a go at guessing the word ").upper()
    if wordGuess == word:
        print("\nYou guessed the word!")
        break
    
    
    
        
