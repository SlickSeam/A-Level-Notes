from socket import *

#host = gethostname()
host = "10.0.72.220"
port = 6060
buf = 128

serverAddress = (host,port)
sock = socket(AF_INET,SOCK_DGRAM)
sock.bind(serverAddress)

while True:
    (msg, serverAddress) = sock.recvfrom(buf)
    print("RECEIVED MSG - " + msg.decode(encoding="UTF-8").strip())
