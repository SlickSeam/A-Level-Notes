from socket import *
import sys

#host = gethostname()
host = "10.0.72.220"
hostDPP = "10.0.72.165"
hostTom = "10.0.72.112"
port = 6060
buf = 128

serverAddressMe = (host,port)
serverAddressDPP = (hostDPP,port)
serverAddressTom = (hostTom,port)
sock = socket(AF_INET,SOCK_DGRAM)
print("Type a message\n")
sys.stdout.write("My Message: ")

while True:
    msg = bytes("Seam: " + sys.stdin.readline(), "UTF-8")
    if msg == b'Seam: /exit\n':
        break
    sock.sendto(msg,serverAddressMe)
    sock.sendto(msg,serverAddressDPP)
    sock.sendto(msg,serverAddressTom)
    sys.stdout.write("My Message: ")
