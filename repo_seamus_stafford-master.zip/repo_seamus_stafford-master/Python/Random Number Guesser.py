import random
import sys

num = random.randint(1,99)
guessNum = 0

while guessNum < 5:
    while True:
        try:
            guess = int(input("Guess a number between 1 and 99 "))
            if guess > 99 or guess < 1:
                print("This number is out of range")
            else:
                break
        except:
            print("You need to enter a number")
    if guess == num:
        print("You guessed correctly")
        sys.exit()
    guessNum += 1
    if guessNum == 5:
        print("You did not guess the number. It was",num)
        sys.exit()
    
