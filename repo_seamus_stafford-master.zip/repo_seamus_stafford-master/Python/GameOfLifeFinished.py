import numpy as np 
import random

live = 0

myGrid = np.random.randint(0,2,(20,20))
grid2 = np.random.randint(0,2,(20,20))

print(myGrid)
print("")
print(grid2)

def show():
    global myGrid
    print('\n'*25)
    for l in myGrid:
        line = ""
        for n in l:
            if n == 1:
                n = "■"
            elif n == 0:
                n = "□"
            line += n
        print(line)
        

def find():
    global live, myGrid, grid2
    num = 0
    while num != 20:
        num2 = 0
        while num2 != 20:
            indNum = myGrid[num][num2]
            neighbour(num,num2)
            #############################
            newGrid(indNum,num,num2)
            #############################
            num2 += 1
        num += 1
    gridSwap()
    

def newGrid(indNum,num,num2):
    global grid2, live
    if indNum == 1:
        if live < 2:
            grid2[num][num2] = 0
        if live >= 2:
            if live <=3:
                grid2[num][num2] = 1
        if live > 3:
            grid2[num][num2] = 0

    else:
        if live == 3:
            grid2[num][num2] = 1

def gridSwap():
    global myGrid, grid2
    num = 0
    while num != 20:
        myGrid[num] = grid2[num]
        num += 1
        
    
def neighbour(num,num2):
    global live
    live = 0
    if num > 0:
        if myGrid[num - 1][num2] == 1:
            live += 1
        ######
        if num2 > 0:
            if myGrid[num - 1][num2 - 1] == 1:
                live += 1
        if num2 < 19:
            if myGrid[num - 1][num2 + 1] == 1:
                live += 1
    if num < 19:
        if myGrid[num + 1][num2] == 1:
            live += 1
        ######
        if num2 > 0:
            if myGrid[num + 1][num2 - 1] == 1:
                live += 1
        if num2 < 19:
            if myGrid[num + 1][num2 + 1] == 1:
                live += 1
    if num2 > 0:
        if myGrid[num][num2 - 1] == 1:
            live += 1
    if num2 < 19:
        if myGrid[num][num2 + 1] == 1:
            live += 1
    return live

def mainLoop():
    global myGrid
    run = True
    while run == True:
        show()
        print("")
        input("Press enter ")
        find()
            
mainLoop()


















