import random
num, guessNum = random.randint(1,99), 0
while guessNum < 5:
    guess = int(input("Guess a number between 1 and 99 "))
    if guess == num:
        print("You guessed correctly")
        exit()
    guessNum += 1
    if guessNum == 5:
        print("You did not guess the number. It was",num)
        exit()
    
