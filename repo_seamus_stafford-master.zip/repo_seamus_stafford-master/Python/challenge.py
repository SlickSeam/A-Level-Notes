while True:
    try:
        HowFar = int(input("How far to count? "))
        if HowFar < 1:
            print("Not a valid number, please try again. ")
        else:
            break
    except:
        print("You need to enter a number")

for MyLoop in range(1,HowFar+1):
    if MyLoop %3 == 0 and MyLoop %5 == 0:
        print("FizzBuzz")
    elif MyLoop %3 == 0:
        print("Fizz")
    elif MyLoop %5 == 0:
        print("Buzz")
    else:
        print(MyLoop)
    
        
