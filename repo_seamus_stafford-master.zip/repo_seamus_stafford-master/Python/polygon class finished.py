import math
import matplotlib.pyplot as pl

class Polygon:
    def __init__(self,vertices):
        if len(vertices) < 3:
            raise Exception("Invalid number of vertices. ")
        else:
            self.vertices = vertices

    def addPoint(self,vertex):
        self.vertex = vertex
        self.vertices += [self.vertex]
        return self.vertex,self.vertices

    def getPerimeter(self):
        self.vertices += [self.vertices[0]]
        perimeter = 0
        for i in range(len(self.vertices)-1):
            perimeter = Polygon.getDistance(self.vertices[i],self.vertices[i+1])
            perimeter = round(perimeter,3)
        return perimeter

    def getDistance(p0,p1):
        distance = math.sqrt((p0[0]-p1[0])**2 + (p0[1]-p1[1])**2)
        return distance                                   

    def plotPoly(self):
        self.vertices += [self.vertices[0]]
        for i in range(len(self.vertices)-1):
            pl.plot((self.vertices[i][0], self.vertices[i+1][0]),(self.vertices[i][1], self.vertices[i+1][1]))
        pl.show()
            

    def getNumOfSides(self):
        return len(self.vertices)
    

vertices = [[0,1],[0,3],[5,2]]

poly = Polygon(vertices)

#to get the perimeter >> poly.getPerimeter()
