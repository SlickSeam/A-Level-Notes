layout = '''b+++++++++
++++++++++
++++++++++
++++++++++
++++++++++
++++++++++
++++++++++
++++++++++
'''
import random
score = 0

def genBoard(theLayout):
    board = []
    row = []
    for i in theLayout:
        row.append(i)
        if i == '\n':
            board.append(row)
            row = []
    return board

def placeEggs(board):
    coordList = []
    for i in range(6):
        done = False
        while done == False:
            coord = [random.randint(0,7),random.randint(0,9)]
            if coord not in coordList:
                if board[coord[0]][coord[1]] != "b":
                    coordList.append(coord)
                    board[coord[0]][coord[1]] = "o"
                    done = True
    return board
            
def displayBoard(board):
    print("\n"*50)
    print("---------------------")
    for row in board:
        for character in row:
            if character == "+":
                character = " "
            if character == "b":
                character = "b"
            if character == "o":
                character = " "
            print("|" + character, end = "")
        print("---------------------")

def move(board):
    global myX, myY, score
    direction = input("\nMove: ").lower()    
    myOldX, myOldY = myX, myY
    move = False
    if direction == 'w':
        if myY != 0:
            myY -= 1
            move = True   
    if direction == 'd':
        if myX != 9:
            myX += 1
            move = True
    if direction == 's':
        if myY != 7:
            myY += 1
            move = True
    if direction == 'a':
        if myX != 0:
            myX -=1
            move = True
    if move == True:
        score += 1
        board[myY][myX] = "b"
        board[myOldY][myOldX] = "+"
    return board
    
def playGame(board):
    run = True
    while run == True:
        displayBoard(board)
        checkWon(board)
        move(board)
        if checkWon(board) == True:
            break

def checkWon(board):
    global score
    eggs = 6
    for row in board:
        for character in row:
            if character == "o":
                eggs -= 1
    print("\nYou have found",eggs,"eggs")
    if eggs == 6:
        displayBoard(board)
        print("\nYOU WON!\n")
        print("You took",score,"turns to collect all the eggs")
        return True
            
def menu():
    while True:
        try:
            menuPick = int(input('''=====MENU=====
1. Timed?
2. Load game
3. Generate board
4. Quit
'''))
            if menuPick > 4 or menuPick < 1:
                print("\nThis is out of range\n")
            else:
                break
        except:
            print("\nYou need to enter a number\n")
    if menuPick == 1:
        timed()
    elif menuPick == 2:
        loadGame()
    elif menuPick == 3:
        board = genBoard(layout)
        placeEggs(board)
        playGame(board)

    else:
        quit()
        
myX,myY = 0,0
menu()
